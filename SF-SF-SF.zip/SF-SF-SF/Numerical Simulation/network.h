/*#ifndef network
#define network*/

#include <map>
#include <cassert>
#include <iostream>
#include <vector>
#include <sstream>
#include <string>
#include <fstream>
#include <set>
#include <ctime>
#include <list>
#include <algorithm>    // std::random_shuffle
#include <memory.h>
#include <math.h>
#include "mt19937ar.h"
#define AVE 64

using namespace std;

int const N = 200000;
double const rou_0 = 0.17;
double const theta =0.1;
double const z = 20;

double w_1 = 1.0; 
double w_2 = 1.0;


int CLUSTER[N]; // 0 STANDS FOR Cluster A; 1 STANDS FOR CLUSTER B;

int M = z*N/2; //total number of links

double S_A =0;
double S_B =0;

//// SF NETWORKS///////////
double const lambda = 2.5;
int const kmax = 1000;
double P_K[N];
///////////////////////////

int LABEL[N];
double DEGREE[N];

//#define EMPTY (-M-1)

extern mt19937 rand_num;
typedef  std::vector<std::set <int> > Net; // needs laboratory's library

//#endif // 3CLIQUE_H
