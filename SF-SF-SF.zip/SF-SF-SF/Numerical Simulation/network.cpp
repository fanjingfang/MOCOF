#include <iostream>
#include <queue>
#include "network.h"
#include "mpi.h"

mt19937 rand_num;

Net net;

string int2str(int i)
{
    string s;
    stringstream ss(s);
    ss << i;

    return ss.str();
}


string double2str(double i)
{
    string s;
    stringstream ss(s);
    ss << i;

    return ss.str();
}

double PK2(double k,double kmin)
{
    return pow(k/kmin,1.0-lambda)-pow((k+1)/kmin,1.0-lambda);
}

double SUM(double kmin)
{
    double sum0=0.0;
    for (double k=kmin;k<=kmax;k++)
    {sum0+=PK2(k,kmin)*k;}
    return sum0;
}

bool all_equal(deque<int> degree_list)
{
    int num_ =0;
    int value_ = degree_list.at(0);
    int len = degree_list.size();
    for (int i = 0; i < len; i++)
    {
        if( degree_list.at(i) == value_) num_++;
    }

    return num_ == len;

}


void TWO_Communities(double nu)  //construct a network with two communities
{
    net.resize(N);
    for (int i=0;i<N;i++) // DEGREE
    {
        DEGREE[i] = 0;
    }

    double k_ave= (1 - nu) * z; //average degree 

    double k_min = 1;
    double PSI;

    for (double k=1; k<kmax; k++)
    {
        double sum_0 = SUM(k);
        PSI = 1 - k_ave/sum_0;

        if(PSI>=0 && PSI <1)
        {
            k_min = k;
            break;
        }
    }


    P_K[0] = PSI;

    for (double k =k_min;k<=kmax;k++)
    {
        P_K[int(k)] = (1.0-PSI)*PK2(k,k_min);
    }

    int num_nodes = N/2;

    vector<int> nodesindex;
    vector<int> nodesindex1;

    for (int i =0; i < num_nodes; ++i) nodesindex.push_back(i);
    random_shuffle ( nodesindex.begin(), nodesindex.end() );

    for (int i = 0; i < num_nodes; ++i) nodesindex1.push_back(i+num_nodes);
    random_shuffle ( nodesindex1.begin(), nodesindex1.end() );

    // cout<<"OK1"<<endl;
    
    deque<int> degree_list_A;
    deque<int> degree_list_B;

    int ka1=0;
    int ka2=0;

    int kb1=0;
    int kb2=0;
    for (double k =k_min; k<kmax; k++)
    {   
        int num_k_nodes = int( N / 2  * P_K[int(k)]); //NUMBER OF NODES HAVEING K DEGREE
        ka2= ka1 + num_k_nodes ;                   //GROUP A
        
        for (int j = ka1; j < ka2; ++j) 
        {
            for (int i = 0; i < k; ++i)
                degree_list_A.push_back(nodesindex[j]);        
        }
        
        ka1=ka2;
        kb2= kb1 + num_k_nodes;                 //GROUP B
        for (int j = kb1; j < kb2; ++j) 
        {
            for (int i = 0; i < k; ++i)
                degree_list_B.push_back(nodesindex1[j]);        
        }
        kb1=kb2;

    }
    // cout<<"OK2"<<"Asize: "<< degree_list_A.size() <<endl;

    int n1,n2,q1,q2;

    while(degree_list_A.size()>0)
    {
        n1=degree_list_A.size()*rand_num.genrand_real2(); // 随机的选择位置。。
        q1 = degree_list_A.at(n1);

        n2=degree_list_A.size() * rand_num.genrand_real2();
        q2 = degree_list_A.at(n2);

        if(q2 == q1) // || net[q2].find(q1) != net[q1].end())
        {
            // cout << q1 <<", ,"<< q2 << endl;
            continue;

        }
        else
        {
	    //cout << degree_list_A.size() << endl;
            net[q1].insert(q2);
            net[q2].insert(q1);
            DEGREE[q1]+=1;
            DEGREE[q2]+=1;
	    
            swap( degree_list_A.at(0), degree_list_A.at(n1));

	    swap( degree_list_A.at(1), degree_list_A.at(n2));
            
	    degree_list_A.pop_front();

	    degree_list_A.pop_front();
        }

	if (degree_list_A.size() < 50)
	{
        if(degree_list_A.size() <= 2 || all_equal( degree_list_A)) break;
	}
    }
    
    // cout<<"all ok?"<<"Bsize "<< degree_list_B.size() <<endl;
    // cout<< net.size() <<endl;

    while(degree_list_B.size()>0)
    {
        n1=degree_list_B.size()*rand_num.genrand_real2(); // 随机的选择位置。。
        q1 = degree_list_B.at(n1);

        n2=degree_list_B.size() * rand_num.genrand_real2();
        q2 = degree_list_B.at(n2);

        if(q2 == q1) //|| net[q2].find(q1) != net[q1].end())
        {
            continue;

        }
        else
        {
	    //cout <<"B  "<< degree_list_B.size() << endl;
            net[q1].insert(q2);
            net[q2].insert(q1);
            DEGREE[q1]+=1;
            DEGREE[q2]+=1;

            swap( degree_list_B.at(0), degree_list_B.at(n1));

            swap( degree_list_B.at(1), degree_list_B.at(n2));
            degree_list_B.pop_front();

            degree_list_B.pop_front();
        }

	if (degree_list_B.size() < 50)
	{
        if(degree_list_B.size() <= 2 || all_equal( degree_list_B)) break;
    	}
    }

    // cout<<","<< degree_list_A.size()<<","<< degree_list_B.size() <<endl;

    //////     SF NETWORKS          //////////

    k_ave= nu*z; //average degree 

    for (double k=1; k<kmax;k++)
    {
        double sum_0 = SUM(k);
        PSI = 1 - k_ave/sum_0;

        if(PSI>=0 && PSI <1)
        {
            k_min = k;
            break;
        }
    }


    P_K[0] = PSI;

    for (double k =k_min;k<=kmax;k++)
    {
        P_K[int(k)] = (1.0-PSI)*PK2(k,k_min);
    }


    // *************************************************************************************************
    deque<int> degree_list_a;
    deque<int> degree_list_b;

    random_shuffle ( nodesindex.begin(), nodesindex.end() );
    random_shuffle ( nodesindex1.begin(), nodesindex1.end() );
    /////////////////////////////////////////////////////////// 

    //--------------assign rest part normally------------------

    ka1=0;
    ka2=0;

    kb1=0;
    kb2=0;
    for (double k =k_min;k<kmax;k++)
    {   
        int num_k_nodes = int( N * P_K[int(k)]); //NUMBER OF NODES HAVEING K DEGREE
        ka2=ka1+num_k_nodes/2;                   //GROUP A
        
        for (int j = ka1; j < ka2; ++j) 
        {
            for (int i = 0; i < k; ++i)
                degree_list_a.push_back(nodesindex[j]);        
        }
        
        ka1=ka2;
        kb2=kb1+num_k_nodes/2;                 //GROUP B
        for (int j = kb1; j < kb2; ++j) 
        {
            for (int i = 0; i < k; ++i)
                degree_list_b.push_back(nodesindex1[j]);        
        }
        kb1=kb2;

    }

   ///////////////////////////////////////////////////////
   //    cout<< "A: "<< degree_list_a.size() << "B: "<< degree_list_b.size() <<endl;
    while(degree_list_a.size()>0 && degree_list_b.size()>0)
    {
        n1=degree_list_a.size()*rand_num.genrand_real2(); // 随机的选择位置。。
        q1 = degree_list_a.at(n1);
        swap(degree_list_a.at(0),degree_list_a.at(n1)); // 保证时间复杂度，O（1） 将位置n1 与 0 的数字换掉。。这要比erase好了很多倍//
        degree_list_a.pop_front(); //删除最前面的数字//

        n2=degree_list_b.size() * rand_num.genrand_real2();
        q2 = degree_list_b.at(n2);
        swap( degree_list_b.at(0), degree_list_b.at(n2));
        degree_list_b.pop_front();
        net[q1].insert(q2);
        net[q2].insert(q1);
        DEGREE[q1] += 1;
        DEGREE[q2] += 1;

        if(degree_list_a.size()<=1 || degree_list_b.size()<=1) break;
    }


}

void diffusion(FILE *fp, double w_1_, double w_2_)
{
    //groupA.clear();
    //groupB.clear();
    double SA = 0;
    double SB = 0;
    double S = 0;
    queue <int> q;// FIFO
    for (int i=0;i<N;i++) // 0 INACTIVE; 1 ACTIVE;
    {
    LABEL[i] = 0;
    if(i<N/2)
    {
        CLUSTER[i] = 0;
    }
    else
    {
        CLUSTER[i] =1;
    }
    }
    int N_0 = rou_0*N;  //
    for (int i = 0;i<N_0;i++)
    {
     int node = (int) N/2*rand_num.genrand_real2(); // from group A
     if(LABEL[node] ==1)
     {
        i--;
        continue;
     }
     else
     {
        LABEL[node] = 1;
        q.push(node);
        SA +=1;
        S +=1;
     }
    }

    //cout<<SA<<","<<N_0<<endl;
    int v = q.front();
    q.pop();
    do
    {
        if(q.empty()) break;
        for (set<int>::iterator  it=net[v].begin(); it!=net[v].end(); it++)
        {
            if(LABEL[*it] == 0)
            {

                int cluster_1 = CLUSTER[*it];

                double tem =0;
                double n_intra = 0;
                double n_inter = 0;

                double tem2 = DEGREE[*it]; 
                for (set<int>::iterator  it1=net[*it].begin(); it1!=net[*it].end(); it1++)
                {
                    if(LABEL[*it1] ==1)
                    {
                        int cluster_2 = CLUSTER[*it1];

                        if (cluster_1==cluster_2)
                        {
                            n_intra+=1;
                        }
                        else
                        {
                            n_inter+=1;
                        }
                    }
                }
                tem  = w_1_*n_intra + w_2_*n_inter;
                if(theta*tem2 < tem)
                {
                    q.push(*it);
                    LABEL[*it] =1;
                    S+=1;
                    if(*it <N/2)
                    {
                        SA+=1;
                    }
                else SB +=1;
                }
            }
        }
        v = q.front();
        q.pop();
        if(q.empty()) break;

    }while(1);

    S_A =2*SA/N;
    S_B =2*SB/N;
    //cout<<","<<SA<<","<<SB<<endl;
    setbuf(fp,NULL);
    fprintf(fp,"%.10f %.10f\n", S_A,S_B);
    net.clear();

}

int main(int argc,char **argv)
{
    int rank;
    int size;
    double s_a;
    double s_b;
    
    string str1= int2str((int)N);
//     string dir = "./data/";
    string str2 = double2str(theta);
    string str3 = double2str(rou_0);
    string strlam = double2str(lambda);
    
    string str4x=".out";
    
    double nu = 0.9;
    
    string str4 = int2str((int)z);
    string str5 = double2str(nu);
        
    string dir2 = "theta" +str2 + "rho" + str3 + "N" + str1 + "z" + str4 + "mu" + str5 + "lam" + strlam; 
    
    string command;
    command = "mkdir -p " + dir2;
    system(command.c_str());

    MPI_Init(&argc,&argv);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    rand_num.init_genrand((unsigned)time( NULL )+rank);
 
    for(double w1 = 0.0; w1 < 1.001; w1 += 0.025)
    {
        
        for(double w2 = 0.0; w2 < 1.001; w2 += 0.025)
        {
        
//         for(double nu = 0.0; nu < 1.001; nu += 0.01)
//         {
            S_A = 0;
            S_B = 0;
            string str51 = double2str(w2);
            string str31 = double2str(w1);
            string filename1 = dir2+"/w1"+str31+"w2"+str51+str4x;

            FILE *fp1;

            fp1=fopen(filename1.c_str(),"ab");

            for(int i=rank+1;i<=AVE;i+=size)
            {
                TWO_Communities(nu);
                diffusion(fp1, w1, w2);
            }
            MPI_Reduce(&S_A,&s_a,1,MPI_DOUBLE,MPI_SUM,0,MPI_COMM_WORLD);
            MPI_Reduce(&S_B,&s_b,1,MPI_DOUBLE,MPI_SUM,0,MPI_COMM_WORLD);

            fclose(fp1);
        }
        
    }
    MPI_Finalize();



    return 0;
}
