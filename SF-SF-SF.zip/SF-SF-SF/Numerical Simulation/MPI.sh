#!/bin/bash

mpirun -np 30 $PWD/network


#module purge
#module load intel/2018.3

# To run on a login node, uncomment this line
#     export I_MPI_FABRICS=shm:shm
# To run on a compute node, either do
#     unset I_MPI_FABRICS 
# or
#     export I_MPI_FABRICS=shm:dapl

## srun version (requires SLURM's process management interface (libpmi) to srun)
#export I_MPI_PMI_LIBRARY=/p/system/slurm/lib/libpmi.so
#srun -n $SLURM_NTASKS $PWD/percolation

## mpirun version
## First, comment out the I_MPI_PMI_LIBRARY line above.
#echo SLURM JOB NODELIST   : $SLURM_JOB_NODELIST
#echo SLURM TASKS PER NODE : $SLURM_TASKS_PER_NODE
#I_MPI_DEBUG=5 mpirun -bootstrap slurm -n $SLURM_NTASKS $PWD/percolation
