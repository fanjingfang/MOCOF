#include <iostream>
#include <queue>
#include "network.h"
#include "mpi.h"

mt19937 rand_num;
Net net;

string int2str(int i)
{
    string s;
    stringstream ss(s);
    ss << i;

    return ss.str();
}

string double2str(double i)
{
    string s;
    stringstream ss(s);
    ss << i;

    return ss.str();
}

void TWO_Communities(double nu)  //construct a network with two communities
{
    net.resize(N);
    for (int i=0;i<N;i++) // DEGREE
    {
    DEGREE[i] = 0;
    }

    int M_inter = nu*M; // 
    int M_intra = M-M_inter; //

    for (int i =0;i<M_intra;i++)
    {
        int node1 = (int) N*rand_num.genrand_real2();
        // if node1 in community A (< N/2), node2 must chose from community A
        if(node1 <N/2)
        {
            int node2 = (int) N/2*rand_num.genrand_real2();
            if(node1==node2 || net[node1].find(node2) != net[node1].end())
            {
                i--;
                continue;

            }
            else
            {
                net[node1].insert(node2);
                net[node2].insert(node1);
                DEGREE[node1]+=1;
                DEGREE[node2]+=1;
            }
        }

        else           // if node1 in community B (>= N/2), node2 must chose from community B

        {
            int node2 = (int) N/2*rand_num.genrand_real2() + N/2;
            if(node1==node2 || net[node1].find(node2) != net[node1].end())
            {
                i--;continue;

            }
            else
            {
                net[node1].insert(node2);
                net[node2].insert(node1);
                DEGREE[node1]+=1;
                DEGREE[node2]+=1;
            }

        }
    }
    // Poisson distribution and ER network
    for (int i =0;i<M_inter;i++)
    {
        int node1 = (int) N*rand_num.genrand_real2();
        // if node1 in community A (< N/2), node2 must chose from [N/2,N]
        if(node1 <N/2)
        {

            int node2 = (int) N/2*rand_num.genrand_real2() + N/2;
            if(net[node1].find(node2) != net[node1].end())
            {
                i--;continue;

            }
            else
            {
                net[node1].insert(node2);
                net[node2].insert(node1);
                DEGREE[node1]+=1;
                DEGREE[node2]+=1;
            }

        }

        else
        {
            //int node2 = (int) N*rand_num.genrand_real2()/2 + N/2;
            int node2 = (int) N/2*rand_num.genrand_real2();
            if(net[node1].find(node2) != net[node1].end())
            {
                i--;continue;

            }
            else
            {
                net[node1].insert(node2);
                net[node2].insert(node1);
                DEGREE[node1]+=1;
                DEGREE[node2]+=1;
            }

        }
    }
    //cout<<M_inter<<","<<M_intra<<endl;

}

void diffusion(FILE *fp, double w_1_, double w_2_)
{
    //groupA.clear();
    //groupB.clear();
    double SA = 0;
    double SB = 0;
    double S = 0;
    queue <int> q;// FIFO
    for (int i=0;i<N;i++) // 0 INACTIVE; 1 ACTIVE;
    {
    LABEL[i] = 0;
    if(i<N/2)
    {
        CLUSTER[i] = 0;
    }
    else
    {
        CLUSTER[i] =1;
    }
    }

    int N_0 = rou_0*N;  //
    for (int i = 0;i<N_0;i++)
    {
     int node = (int) N/2*rand_num.genrand_real2(); // from group A
     if(LABEL[node] ==1)
     {
        i--;
        continue;
     }
     else
     {
        LABEL[node] = 1;
        q.push(node);
        SA +=1;
        S +=1;

     }
    }

    //cout<<SA<<","<<N_0<<endl;


int v = q.front();
q.pop();
do
{
    if(q.empty()) break;
    for (set<int>::iterator  it=net[v].begin(); it!=net[v].end(); it++)
    {
        if(LABEL[*it] == 0)
        {

        int cluster_1 = CLUSTER[*it];

        double tem =0;
        double n_intra = 0;
        double n_inter = 0;

        double tem2 = DEGREE[*it]; 
        for (set<int>::iterator  it1=net[*it].begin(); it1!=net[*it].end(); it1++)
        {
            if(LABEL[*it1] ==1)
            {
                int cluster_2 = CLUSTER[*it1];

                if (cluster_1==cluster_2)
                {
                    n_intra+=1;
                }
                else
                {
                    n_inter+=1;
                }
                //tem+=1;
            }
            //tem2+=1;

        }
        tem  = w_1_*n_intra + w_2_*n_inter;
        if(theta*tem2 < tem)
        {
          q.push(*it);
          LABEL[*it] =1;
          S+=1;
          if(*it <N/2)
          {
              SA+=1;
          }
          else SB +=1;
        }
        }
    }
    v = q.front();
    q.pop();
    if(q.empty()) break;


}while(1);

S_A =2*SA/N;
S_B =2*SB/N;
//cout<<","<<SA<<","<<SB<<endl;
setbuf(fp,NULL);
fprintf(fp,"%.10f %.10f\n", S_A,S_B);
net.clear();

}


int main(int argc,char **argv)
{
    int rank;
    int size;
    double s_a;
    double s_b;
    
    string str1= int2str((int)N);
    string dir = "./data/";
//     string dir2 = "./data1/"; 

//     string str2 = double2str(theta);
//     string str3 = double2str(rou_0);
//     string str31 = double2str(Beta);

//     string str4=".dat";
    string str4x=".out";

//     string filename2=dir+"N"+str1+"theta"+str2+"rou"+str3+"beta"+str31+str4;

//     FILE *fp2;
//     fp2=fopen(filename2.c_str(),"wb");

    MPI_Init(&argc,&argv);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    rand_num.init_genrand((unsigned)time( NULL )+rank);
    
    // double nu = 0.55;
    
    // double w1 = 0.8;   //0.2, 0.7, 0.8 1
    double w2 = 1; //0.2, 0.7, 0.8 1
    
    double nu = 0.8; //, 0.5, 0.8
    
    for(double w1 = 0.0; w1 < 1.001; w1 += 0.01)
    {
        
//         for(double w2 = 0.0; w2 < 1.001; w2 += 0.01)
//         {
        
    // for(double nu = 0.0; nu < 1.001; nu += 0.01)
    // {
        S_A = 0;
        S_B = 0;
        string str5 = double2str(w2);
        string str31 = double2str(w1);
        string str_nu = double2str(nu);
        
        // string dir = "./w1"+str31+"w2"+str5+"/";
        // string filename1=dir+"nu"+str_nu+str4x;
        
        string dir = "./nu"+str_nu+"w21/";
        string filename1=dir+"w1"+str31+str4x;

        FILE *fp1;

        fp1=fopen(filename1.c_str(),"ab");

        for(int i=rank+1;i<=AVE;i+=size)
        {
            TWO_Communities(nu);
            diffusion(fp1, w1, w2);
        }
        MPI_Reduce(&S_A,&s_a,1,MPI_DOUBLE,MPI_SUM,0,MPI_COMM_WORLD);
        MPI_Reduce(&S_B,&s_b,1,MPI_DOUBLE,MPI_SUM,0,MPI_COMM_WORLD);

        fclose(fp1);

    }
        
    // }
    MPI_Finalize();



    return 0;
}


