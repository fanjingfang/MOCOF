from sklearn.model_selection import ParameterGrid
import numpy as np
from multiprocessing import Pool

from scipy.optimize import root
from tqdm import tqdm

import math
import time

import warnings
warnings.filterwarnings("ignore")

import scipy.stats as scis
ppmf  = scis.poisson.pmf

import matplotlib.pyplot as plt
import pickle

import os

def bipmf(k, n, p):
    
    """
    binomial distribution, can run faster than the function given in scipy module
    """
    
    if k > n: return 0
    
    output = math.factorial(n)/(math.factorial(k)*math.factorial(n-k)) *\
        p**(k)*(1-p)**(n-k)
        
    return output
    
def pd(k, kx, lam):
    
    if kx == 0:
        if k == 0: 
            return 1
        else:
            return 0
    
    kmax = 1000
#     find the optimal value of kmin        
    for kmin_ in range(1, 100):
        sum_ = 0
        P = lambda k :(k/kmin_)**(1-lam) - ((k+1)/kmin_)**(1-lam)
        for k_ in range(kmin_, kmax):
            
            sum_ += P(k_)*k_

        Psi = 1 - kx/sum_

        if (Psi > 0) & (Psi < 1): 
            kmin = kmin_
            break
                
    Pl = lambda k :(k/kmin)**(1-lam) - ((k+1)/kmin)**(1-lam)
    
    sum_ = 0 
    for k_ in range(kmin, kmax):
        sum_ += Pl(k_)*k_

    Psi = 1 - kx/sum_
    
    if k == 0: return Psi
    elif k < kmin: return 0
    else: return (1-Psi)*Pl(k)

def MF_2m(rho_inf, rho_0, theta = 0.4, z = 20, mu = 0.1, N_c1 = 60, N_c2 = 100, w1 = 1, w2 = 1, lam = 0):

    output = np.zeros((2,))
    rho_A = rho_0 *2
    rho_B = 0
    
    z1 = z * (1 - mu)
    z2 = z * mu
    
    for k1 in range(N_c1 +1):
        
        for k2 in range(N_c2 +1):
            
            if lam < 2:            
                c1 = ppmf(k1, z1) * ppmf(k2, z2)
            else:
                c1 = ppmf(k1, z1) * pd(k2, z2, lam)
                
            for k1p in range(0, k1+1):
 
                for k2p in range( 0, k2+1):
                    
                    if (k1p * w1 + k2p * w2) > theta*(k1+k2): # dynamical term
                                            
                        output[0] += (1 - rho_A) * c1 *\
                            bipmf(k1p, k1, rho_inf[0]) * bipmf(k2p, k2, rho_inf[1])
                        
                        output[1] += (1 - rho_B) * c1 *\
                            bipmf(k1p, k1, rho_inf[1]) * bipmf(k2p, k2, rho_inf[0])
                                        
    return [output[0] + rho_A, output[1] + rho_B]


def TL_2m(yn_inf, rho_0, theta = 0.4, z = 20, mu = 0.1, N_c1 = 60, N_c2 = 100, w1 = 1, w2 =1, lam = 0):

    output = np.zeros((2,))
    rho_A = rho_0 *2
    rho_B = 0
    
    z1 = z * (1 - mu)
    z2 = z * mu
    
    for k1 in range( N_c1 +1):
        
        for k2 in range( N_c2 +1):
            
            if lam < 2:
                coe = 1/(z1 + z2) * ppmf(k1, z1) * ppmf(k2, z2)
            else:
                coe = 1/(z1 + z2) * ppmf(k1, z1) * pd(k2, z2, lam)
            
            for k1p in range(k1+1):                        
                               
                for k2p in range(0, k2+1):
                    
                    if (k1p * w1 + k2p * w2) > theta * (k1 + k2): # dynamical term
                    
                        output[0] += (1 -rho_A)* coe *\
                            ( k1 *bipmf(k1p, k1-1, yn_inf[0]) *bipmf(k2p, k2, yn_inf[1]) +\
                             k2 *bipmf(k1p, k1, yn_inf[0]) *bipmf(k2p, k2-1, yn_inf[1]))
                                                                
                        output[1] += (1 -rho_B)* coe *\
                            ( k1 *bipmf(k1p, k1-1, yn_inf[1]) *bipmf(k2p, k2, yn_inf[0]) +\
                             k2 *bipmf(k1p, k1, yn_inf[1]) *bipmf(k2p, k2-1, yn_inf[0]))      
                                      
    return [output[0] + rho_A, output[1] + rho_B]


def TL(param):
        
    if 'theta' in param.keys():
        theta_ = param['theta']
    else:
        theta_ = 0.4
        
    if 'mu' in param.keys():
        mu_ = param['mu']
    else:
        print(r'error, there is no $\mu$!')
        
    if 'w1' in param.keys():
        w1_ = param['w1']
    else:
        w1_ = 1
        
    if 'w2' in param.keys():
        w2_ = param['w2']
    else:
        w2_ = 1
        
    if 'lam' in param.keys():
        lam_ = param['lam']
    else:
        lam_ = 0
    
    rho_0 = 0.17
    
    y0 =  np.array( [ rho_0 *2, 0])
    n = 0
    
    for i in range(1000):
        
        y1 = TL_2m(y0, rho_0, mu = mu_, theta = theta_, \
                   w1 = w1_, w2 = w2_, lam = lam_)
        n +=1
        
        if np.mean( (np.array(y1) - y0) **2) < 1e-12: break
    
        y0 = y1
        
    rho =  MF_2m(y0, rho_0, mu = mu_, theta = theta_, \
                 w1 = w1_, w2 = w2_, lam = lam_)
    
    return rho, n 


def MF(param):
    
    if 'theta' in param.keys():
        theta_ = param['theta']
    else:
        theta_ = 0.4
        
    if 'mu' in param.keys():
        mu_ = param['mu']
    else:
        print(r'error, there is no $\mu$!')
        
    if 'w1' in param.keys():
        w1_ = param['w1']
    else:
        w1_ = 1
        
    if 'w2' in param.keys():
        w2_ = param['w2']
    else:
        w2_ = 1
                
    rho_0 = 0.1
    
    func_p = lambda x: MF_2m(x, rho_0, mu = mu_, w1 = w1_, \
                             w2 = w2_, theta = theta_) -x
    
    root_p = root(func_p, [2*rho_0,  0], method = 'excitingmixing')
    
    return root_p.x   