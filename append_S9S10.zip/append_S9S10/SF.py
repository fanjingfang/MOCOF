from sklearn.model_selection import ParameterGrid
import numpy as np
from multiprocessing import Pool

from scipy.optimize import root
from tqdm import tqdm

import math
import time

import warnings
warnings.filterwarnings("ignore")

import scipy.stats as scis
ppmf  = scis.poisson.pmf

import matplotlib.pyplot as plt
import pickle

import os

from custom_functions2 import bipmf, MF_2m, TL_2m, TL, MF


tb = time.time()

w1_num = 40
w2_num = 40

#     mu_num = 40
#     mu_list = np.linspace(0, 0.5, num_num)

mu_list = list([ 0.2, 0.8]) #, 0.5, 0.9])
C_ = 2
w1_list = np.linspace(0, 1, w1_num).tolist()
w2_list = np.linspace(0, 1, w2_num).tolist()
lam_ = 0

for mu_ in mu_list:

    print( f"multiprocess begins, C = {C_}")

    param_grid = {"mu" : list([mu_]), "w1" : w1_list, "w2" : w2_list, \
                  "lam" : list([lam_]), "C" : list([C_])}
    grid = ParameterGrid( param_grid)
    p = Pool(64)
    jobs = [p.map_async(TL, (grid[i], )) for i in range( len(grid))]
    results = []
    for job in tqdm(jobs):
        results.append( job.get())

    file_path = os.path.join( os.getcwd(), f"RHO_N_C{C_}grid{w1_num}lam{lam_}mu{mu_}.dat")
    pickle.dump(results, open( file_path, "wb"))
    tm = time.time()

    print( (tm - tb)/(60*60*24), "day")
    p.close()
    p.join()


